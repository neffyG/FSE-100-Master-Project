
let MENU = 0
let message = '';


function keyTyped() {
  if(key!='Backspace'){
    message += key;
  }
  else{
    message='';
  }
}


function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(0,0,0)
  print(mouseX, mouseY)
  fill(0, 255, 0);
  rect(100, 50, 600, 75);
  fill(255, 0, 255);
  rect(175, 200, 400, 75);
  fill(255, 0, 0);
  rect(175, 350, 400, 75);
  textSize(50)
  fill(255);  
  text('Stroke No More!', 200, 106);
  text('Settings', 275, 406);
  text('Games', 275, 248);


  if (MENU == 1) {
    background(0, 255, 0)
    fill(0)
    textSize(20)
    text('Right Click to return to MENU', 525, 30)
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  } // Games
  if (MENU == 2) {
    background(0,0,0)
    textSize(40)
    fill(255, 0, 255);
    text('Right Click to return to MENU', 250, 30)
    text('Game 1: Typing', 50, 150)
    text('Game 2: Handwriting', 50, 200)
    text('Game 3: Stability', 50, 250)
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  } 
  if (MENU == 4) {
    background(0, 0, 0)
    textSize(40)
    text('Game 1: Typing', 300, 78)
    text('Type the following:',300,200)
    text('"Hello, How are you?"',420,300)
    text(message, 430, 430);
     if(message=='Hello, How are you?'){
       fill(4,150,75)
       text('Good!!',420,500)
     }
    else{
      fill(200,0,0)
      text('BAD!!',420,500)
    }
  
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  }
  if (MENU == 5) {
    background(0, 0, 0)
    textSize(40)
    fill(200,200,20)
    text('Game 2: Handwriting', 200, 78)
    text('Write the Following',200,200)
    textSize(50)
    text('The Quick Brown Fox',150,300)
    if(mouseX<632 && mouseX>0){
      if(mouseY<300 && mouseY>263){
        fill(4,150,75)
        circle(mouseX, mouseY, 25);
        text('Good!!',200,500)
      }
      if(mouseY<263 && mouseY>0){
        fill(200,0,0)
        circle(mouseX, mouseY, 25);
        text('BAD!!',200,500)
      }
       if(mouseY<600 && mouseY>300){
        fill(200,0,0)
        circle(mouseX, mouseY, 25);
         text('BAD!!',200,500)
      } 
    }
    

     
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  }
  if (MENU == 6) {
    background(0, 0, 0)
    textSize(40)
    fill(150,200,70)
    text('Game 3: Stability', 200, 78)
    text('Follow the line:',200,200)
    textSize(100)
    fill(0,200,0)
    rect(70, 300, 600, 20)
    if(mouseX<668 && mouseX>70){
      if(mouseY<322 && mouseY>300){
        fill(4,150,75)
        circle(mouseX, mouseY, 25);
        textSize(40)
        text('Good keep going !!',200,500)
      }
      if(mouseY<=300 && mouseY>0){
        fill(200,0,0)
        circle(mouseX, mouseY, 25);
        textSize(50)
        text('Keep trying!',200,500)
      }
       if(mouseY<600 && mouseY>=322){
        fill(200,0,0)
         textSize(50)
        circle(mouseX, mouseY, 25);
         text('Almost There!!',200,500)
      } 
    }
    

     
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  }
  
  
  if (MENU == 3) {
    background(255, 0, 0)
    textSize(40)
    text('Right Click to return to MENU', 100, 30)
    text('Volume off/on', 50, 100)
    text('Vibration off/on', 50, 150)
    text('Brightness High/Medium/low',50, 200)
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  } // EXIT 
}

function mouseClicked() {
  if (MENU == 0) {
    if (mouseX < 575 && mouseX > 175) {
      if (mouseY < 106 && mouseY > 0) {
        MENU = 1
      }
      if (mouseY < 275 && mouseY > 200) {
        MENU = 2
      }
      if (mouseY < 425 && mouseY > 353) {
        MENU = 3
      }
      
    }
  }
  if(MENU==2){
    if(mouseX<340 && mouseX>50){
      if(mouseY < 147 && mouseY > 121){
        MENU = 4
      }
    }
  }
  if(MENU==2){
    if(mouseX<340 && mouseX>50){
      if(mouseY < 200 && mouseY > 147){
        MENU = 5
      }
    }
  }
  if(MENU==2){
    if(mouseX<340 && mouseX>50){
      if(mouseY < 250 && mouseY > 220){
        MENU = 6
      }
    }
  }
}